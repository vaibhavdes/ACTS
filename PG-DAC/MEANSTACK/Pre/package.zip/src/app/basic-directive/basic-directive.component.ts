import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'basic-directive',
  templateUrl: './basic-directive.component.html',
})
export class BasicDirectiveComponent{
  flagOne = true;
  flagTwo = false;

  personArr = [
    {id:1,name:"XYZ",city:"Pune"},
    {id:2,name:"ABC",city:"Mumbai"},
    {id:3,name:"CVB",city:"Kolhapur"},
    {id:4,name:"FGH",city:"Sangli"}
  ];

  blankObj = {id:0,name:"",city:""};

  showForm(){
    this.flagOne = !this.flagOne;
    this.flagTwo = !this.flagTwo;
  }

  addObj(){
    this.personArr.push(this.blankObj);
    this.flagTwo = !this.flagTwo;
    this.flagOne = !this.flagOne;
  }
  
}
