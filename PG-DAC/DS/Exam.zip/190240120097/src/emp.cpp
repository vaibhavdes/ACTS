#include<iostream>
#include "emp.h"
using namespace std;

list::list()
{
	top=NULL;
	count=0;
}

void list::display(node *temp)
{
	cout<<endl;	
		cout<<"Employee ID: "<<temp->emp_id<<endl;
		cout<<"Employee Name: "<<temp->emp_name<<endl;
		cout<<"Employee Salary: "<<temp->salary<<endl;
	temp = NULL;
	cout<<endl;
}

void list::insert_emp()
{
	node *temp = new node;
	cout<<"Enter Employee Id"<<endl;
	cin>>temp->emp_id;
	cout<<"Enter Employee Name"<<endl;
	cin>>temp->emp_name;
	cout<<"Enter Employee Salary"<<endl;
	cin>>temp->salary;

	if(top==NULL)
	{
		top=temp;
		temp=NULL;
		count++;
		cout<<"Employee Inserted Succesfully"<<endl;
	}
	else
	{
		temp->next = top;
		top = temp;
		count++;
		cout<<"Employee Inserted Succesfully"<<endl;
	}
	temp = NULL;
}

void list::delete_emp()
{
	cout<<endl;
	if(top==NULL)
	{
		cout<<"No Employee Data Found"<<endl;
	}
	else
	{
		node *temp = new node;
		while(top!=NULL)
		{
			cout<<"Employee ID: "<<top->emp_id<<endl;
			cout<<"Employee Name: "<<top->emp_name<<endl;
			cout<<"Employee Salary: "<<top->salary<<endl<<endl;
			temp=top;
			top=top->next;
			delete temp;
			temp = NULL;
			count--;
		}
		temp = NULL;					
	}
	cout<<endl;
}

void list::counts()
{
	cout<<"No of Employees in Database: "<<count<<endl;	
}

void list::high_low_salary()
{
	int high_salary = 0;
	int low_salary = 999999;

	node *high;
	node *low;

	if(top==NULL)
	{
		cout<<"No Employee Data Found"<<endl;
	}
	else
	{
		node *temp = new node;
		temp = top;
		while(temp!=NULL)
		{
			if(temp->salary > high_salary)
			{
				high_salary = temp->salary;
				high = temp;
			}
			if(temp->salary < low_salary)
			{
				low_salary = temp->salary;
				low = temp;
			}
			temp=temp->next;
		}
		temp=NULL;
	}
	
	if(high_salary != 0)
	{
		cout<<"Highest Salaried Employee is: ";
		display(high);
	}

	if(low_salary != 999999)
	{
		cout<<"Lowest Salaried Employee is: ";
		display(low);
	}
}
