export class person {
    perid;
    pname;
    desg;
    sal;
}