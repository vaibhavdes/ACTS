package dao;

import java.util.List;

import pojo.Product;

public class ProductDao implements IProductDao{

	public ProductDao() {
		System.out.println("In Product Dao::");
	}

	@Override
	public Product addProduct(Product p, List<Product> list) {
		
		return null;
	}

	
	
}
