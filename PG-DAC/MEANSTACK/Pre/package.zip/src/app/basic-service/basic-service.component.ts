import { PersonService } from './person.service';
import { Component, OnInit } from '@angular/core';

/*
Add Following Packages into package.json

    "@angular/http": "^7.2.15"
    "rxjs": "~6.3.3"
    "rxjs-compat": "^6.3.3"

*/

@Component({
  selector: 'basic-service',
  templateUrl: './basic-service.component.html',
  styleUrls: ['./basic-service.component.css']
})
export class BasicServiceComponent implements OnInit {

  parr=[{}];

  constructor(private pservice:PersonService) {}

  ngOnInit() {
    this.pservice.getAllPerson().subscribe((r)=>this.parr=r);
  }

}
