import { WebServiceComponent } from './web-service/web-service.component';
import { AppComponent } from './app.component';
import { BasicServiceComponent } from './basic-service/basic-service.component';
import { BasicObjectComponent } from './basic-object/basic-object.component';
import { BasicInputComponent } from './basic-input/basic-input.component';
import { BasicDirectiveComponent } from './basic-directive/basic-directive.component';
import { Routes,RouterModule } from '@angular/router';
import { NgModel } from '@angular/forms';
import { NgModule } from '@angular/core';


const routes: Routes = [

    {
        path : 'directive', 
        component: BasicDirectiveComponent
    },
    {
        path: 'input',
        component: BasicInputComponent
    },
    {
        path: 'object',
        component: BasicObjectComponent
    },
    {
        path: 'service',
        component: BasicServiceComponent
    },
    {
        path: 'web',
        component: WebServiceComponent
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }