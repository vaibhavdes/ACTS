import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'basic-input',
  templateUrl: './basic-input.component.html',
  styleUrls: ['./basic-input.component.css']
})
export class BasicInputComponent {

  para  = "This is paragraph";
  title = "Angular App"
  sal   = 1123;

  getColor(){
    return 'yellow';
  }

  changePara(){
    this.para="changed Para";
  }
  
}
