package custException;

@SuppressWarnings("serial")
public class ProductCustomException extends Exception {
	public ProductCustomException(String msg) {
		super(msg);
	}

}
