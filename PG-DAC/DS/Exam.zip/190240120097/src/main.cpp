#include<iostream>
#include "emp.h"
#include <cstdlib>
using namespace std;

int main()
{
	list l;

	int option=1;	
	while(option!=0)
	{
		cout<<endl;
		cout<<"1. Add Employee"<<endl;
		cout<<"2. View All Employee"<<endl; 
		cout<<"3. Show Lowest & Highest Salary"<<endl;
		cout<<"4. Count of Employees"<<endl;
		cout<<"0. Exit"<<endl;		
		
		cin>>option;
		switch(option)
		{
			case 1:
				l.insert_emp();
				break;
			case 2: 
				l.delete_emp();
				break;
			case 3:
				l.high_low_salary();
				break;
			case 4:
				l.counts();
				break;
			case 0:
				exit(0);	
		}
	}
}
