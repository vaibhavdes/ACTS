To Compile:

	 g++ src/emp.cpp src/main.cpp -o bin/Employee

To Run
	bin/Employee


