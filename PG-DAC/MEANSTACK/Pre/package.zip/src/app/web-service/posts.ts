export class Post {
    userId;
    id;
    title;
    body;
}