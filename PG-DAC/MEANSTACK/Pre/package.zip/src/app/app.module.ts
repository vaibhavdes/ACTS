import { PostsService } from './web-service/posts.service';
import { AppRoutingModule } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { BasicInputComponent } from './basic-input/basic-input.component';
import { BasicObjectComponent } from './basic-object/basic-object.component';
import { BasicDirectiveComponent } from './basic-directive/basic-directive.component';
import { BasicServiceComponent } from './basic-service/basic-service.component';
import { HttpModule } from '@angular/http';
import { PersonService } from './basic-service/person.service';
import { WebServiceComponent } from './web-service/web-service.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    BasicInputComponent,
    BasicObjectComponent,
    BasicDirectiveComponent,
    BasicServiceComponent,
    WebServiceComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
    PersonService,
    PostsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
