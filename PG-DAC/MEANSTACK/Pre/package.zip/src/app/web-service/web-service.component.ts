import { PostsService } from './posts.service';
import { Component, OnInit } from '@angular/core';
import { Post } from './posts';

@Component({
  selector: 'app-web-service',
  templateUrl: './web-service.component.html',
})
export class WebServiceComponent implements OnInit {

  parr:Post[]

  p:Post={
    "userId": 0,
    "id": 0,
    "title": "",
    "body": ""
  };

  flag=false;

  constructor(private pservice:PostsService) { }

  ngOnInit() {
    this.pservice.getAllPosts().subscribe((r)=>this.parr=r);
  }

  onAddClick(){
    this.flag=true;
  }

  submitForm(){
    this.pservice.addPost(this.p).subscribe((r)=>this.parr=r);
    this.flag=false;
  }

  updatePost(p1:Post){
    this.flag=true;
    this.p.userId=p1.userId;
    this.p.body=p1.body;
    this.p.title=p1.title;
    this.p.id=p1.id;
  }

  deletePost(id:number){
    this.pservice.deletePost(id).subscribe((r)=>this.parr=r);
  }
  
}
