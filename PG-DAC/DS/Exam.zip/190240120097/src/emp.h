struct node
{
		int emp_id;
		int salary;
		char emp_name[20];		
		node *next;
};

class list
{
	private:	
		node *top;
		int count;
	public:
		list();
		void display(node *temp);
		void insert_emp();
		void delete_emp();
		void counts();		
		void high_low_salary();
};
