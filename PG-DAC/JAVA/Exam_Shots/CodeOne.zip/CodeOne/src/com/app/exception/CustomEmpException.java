package com.app.exception;

@SuppressWarnings("serial")
public class CustomEmpException extends Exception{
	public CustomEmpException(String msg) {
		super(msg);
	}
}
