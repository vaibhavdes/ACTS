import { Http, HttpModule } from '@angular/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Post } from './posts';

@Injectable()
export class PostsService {
    baseurl = "https://jsonplaceholder.typicode.com/posts";

    constructor(private http:HttpClient) {}

    getAllPosts():Observable<Post[]>{
        return this.http.get<Post[]>(this.baseurl);
    }

    addPost(p:Post):Observable<Post[]>{
        return this.http.post<Post[]>(this.baseurl,p);
    }

    updatePost(p:Post):Observable<Post[]>{
        return this.http.put<Post[]>(this.baseurl,p);
    }

    deletePost(id:number):Observable<Post[]>{
        return this.http.delete<Post[]>(this.baseurl + "/" + id);
    }

}