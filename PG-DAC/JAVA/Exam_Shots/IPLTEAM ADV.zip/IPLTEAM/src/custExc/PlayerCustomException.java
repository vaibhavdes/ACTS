package custExc;

@SuppressWarnings("serial")
public class PlayerCustomException extends Exception{
	public PlayerCustomException(String msg) {
		super(msg);
	}
}
