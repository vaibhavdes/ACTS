import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'basic-object',
  templateUrl: './basic-object.component.html',
  styleUrls: ['./basic-object.component.css']
})
export class BasicObjectComponent {
  person = {id:1,name:"XYZ",mobile:"+91-99132323",age:21};
}
